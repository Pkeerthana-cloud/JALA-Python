#3. Define variables for different Data Types int, Boolean, char, float, double and print on the Console.
dec= 150
print(bin(dec),"in binary.")
print(oct(dec),"in octal.")
print(hex(dec),"in hexade.")