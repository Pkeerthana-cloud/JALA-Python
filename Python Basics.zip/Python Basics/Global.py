#4. Define the local and Global variables with the same name and print both variables and understand the scope of the variables
def f():
    s = "My name."
    print(s)
    # Global and local scope
    s = "Is Keerthana"
    f()
    print(s)