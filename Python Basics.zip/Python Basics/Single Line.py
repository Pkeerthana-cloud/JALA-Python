#2. Write a program for a Single line comment and multi-line comment
#single line comment
print("Hello JALA")
#it is a
#multiline
#comment
#this is a comment
'this is an unassigned string as a comment '
'''

I am a
multiline comment!

'''
print("Hello World")